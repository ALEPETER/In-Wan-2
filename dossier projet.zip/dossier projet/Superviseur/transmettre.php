<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'superviseur') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id) {
    $stmt = $conn->prepare("UPDATE signalements SET statut = 'transmis_manager', date_transmission_manager = NOW() WHERE id = ?");
    $stmt->execute([$id]);
}
header('Location: dashboard.php');
exit();
?>