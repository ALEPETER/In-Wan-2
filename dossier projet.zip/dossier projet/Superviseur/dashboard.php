<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'superviseur') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

// Incidents à transmettre (statut = valide_chef)
$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.statut = 'valide_chef'
    ORDER BY s.date_signalement DESC
");
$stmt->execute();
$a_transmettre = $stmt->fetchAll();

// Incidents validés par manager (statut = valide_manager)
$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.statut = 'valide_manager'
    ORDER BY s.date_signalement DESC
");
$stmt->execute();
$a_affecter = $stmt->fetchAll();

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Superviseur - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gradient-to-br from-slate-800 to-blue-900 min-h-screen p-6">
    <div class="max-w-6xl mx-auto">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            <div class="bg-gradient-to-r from-blue-800 to-indigo-800 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <div class="bg-white/20 p-1 rounded-lg"><img src="../assets/images/logo.jpg" alt="IN WAN" class="h-8 w-auto"></div>
                    <div><h2 class="text-white font-bold"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2><p class="text-indigo-100 text-xs">Superviseur • <?php echo $date_jour; ?></p></div>
                </div>
                <a href="../logout.php" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full text-sm transition">Déconnexion</a>
            </div>

            <div class="p-6">
                <?php if(isset($_SESSION['flash_message'])): ?>
                    <div class="bg-green-50 border-l-4 border-green-500 text-green-700 p-4 rounded-lg mb-6 text-sm">
                        <?php echo $_SESSION['flash_message']; unset($_SESSION['flash_message']); ?>
                    </div>
                <?php endif; ?>

                <!-- Section 1 : Transmettre -->
                <div class="mb-10">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">📤 Incidents à transmettre au manager</h2>
                    <?php if(count($a_transmettre) > 0): ?>
                        <?php foreach($a_transmettre as $inc): ?>
                            <div class="bg-white border rounded-xl p-4 mb-3 shadow-sm">
                                <div><strong><?php echo $inc['id']; ?></strong> | <?php echo htmlspecialchars($inc['equipement']); ?> (Agent: <?php echo htmlspecialchars($inc['agent_nom']); ?>)</div>
                                <div class="text-sm text-gray-600">Type: <?php echo $inc['type_panne']; ?> • Urgence: <?php echo $inc['urgence']; ?></div>
                                <div class="flex gap-3 mt-3">
                                    <a href="detail.php?id=<?php echo $inc['id']; ?>" class="bg-gray-600 text-white px-3 py-1 rounded text-sm">📄 Détails</a>
                                    <a href="transmettre.php?id=<?php echo $inc['id']; ?>" class="bg-blue-600 text-white px-3 py-1 rounded text-sm" onclick="return confirm('Transmettre au manager ?')">📤 Transmettre</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="bg-gray-50 rounded-xl p-6 text-center text-gray-500">✅ Aucun incident à transmettre.</div>
                    <?php endif; ?>
                </div>

                <!-- Section 2 : Incidents validés par le manager -->
                <div>
                    <h2 class="text-xl font-bold text-gray-800 mb-4">✅ Incidents validés par le manager</h2>
                    <?php if(count($a_affecter) > 0): ?>
                        <?php foreach($a_affecter as $inc): ?>
                            <div class="bg-white border rounded-xl p-4 mb-3 shadow-sm">
                                <div><strong><?php echo $inc['id']; ?></strong> | <?php echo htmlspecialchars($inc['equipement']); ?> (Agent: <?php echo htmlspecialchars($inc['agent_nom']); ?>)</div>
                                <div class="text-sm text-gray-600">Type: <?php echo $inc['type_panne']; ?> • Urgence: <?php echo $inc['urgence']; ?></div>
                                <div class="flex gap-3 mt-3 justify-end">
                                    <a href="message.php?id=<?php echo $inc['id']; ?>" class="bg-indigo-100 hover:bg-indigo-200 text-indigo-700 px-3 py-1 rounded text-sm">💬 Chat</a>
                                    <a href="affecter_technicien.php?id=<?php echo $inc['id']; ?>" class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm">🔧 Affecter technicien</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="bg-gray-50 rounded-xl p-6 text-center text-gray-500">✅ Aucun incident validé par le manager.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>