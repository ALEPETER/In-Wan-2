<?php
session_start();
require_once '../config/database.php';

// Vérifier que c'est bien le chef d'équipe
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'chef_equipe') {
    die("Accès interdit.");
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id > 0) {
    $stmt = $conn->prepare("UPDATE signalements SET statut = 'valide_chef', date_validation_chef = NOW() WHERE id = ?");
    $stmt->execute([$id]);
    echo "Incident validé avec succès. <a href='dashboard.php'>Retour</a>";
} else {
    echo "ID manquant.";
}
?>