<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'agent') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id) {
    // Vérifier que l'incident appartient bien à l'agent
    $stmt = $conn->prepare("SELECT agent_id FROM signalements WHERE id = ?");
    $stmt->execute([$id]);
    $incident = $stmt->fetch();
    if($incident && $incident['agent_id'] == $_SESSION['user_id']) {
        // Supprimer les photos associées (fichiers physiques)
        $stmt = $conn->prepare("SELECT chemin_photo FROM photos WHERE signalement_id = ?");
        $stmt->execute([$id]);
        $photos = $stmt->fetchAll();
        foreach($photos as $photo) {
            $fichier = '../' . $photo['chemin_photo'];
            if(file_exists($fichier)) {
                unlink($fichier);
            }
        }
        // Supprimer les entrées dans la table photos
        $stmt = $conn->prepare("DELETE FROM photos WHERE signalement_id = ?");
        $stmt->execute([$id]);
        // Supprimer l'incident
        $stmt = $conn->prepare("DELETE FROM signalements WHERE id = ?");
        $stmt->execute([$id]);
    }
}
header('Location: dashboard.php');
exit();
?>