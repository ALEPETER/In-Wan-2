<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'technicien') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$incident_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$incident_id) {
    $_SESSION['flash_message'] = "ID d'incident manquant.";
    header('Location: dashboard.php');
    exit();
}

try {
    // Démarrer l'intervention : mettre à jour le signalement
    $stmt = $conn->prepare("UPDATE signalements SET statut = 'en_cours', date_debut_intervention = NOW() WHERE id = ?");
    $stmt->execute([$incident_id]);
    
    // Mettre à jour l'intervention correspondante
    $stmt = $conn->prepare("UPDATE interventions SET date_debut = NOW() WHERE signalement_id = ?");
    $stmt->execute([$incident_id]);
    
    $_SESSION['flash_message'] = "Intervention démarrée avec succès.";
} catch (Exception $e) {
    $_SESSION['flash_message'] = "Erreur: " . $e->getMessage();
}

header('Location: dashboard.php');
exit();
?>