<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'superviseur') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id) {
    header('Location: dashboard.php');
    exit();
}

// Récupérer l'incident
$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.id = ?
");
$stmt->execute([$id]);
$incident = $stmt->fetch();

if(!$incident) {
    header('Location: dashboard.php');
    exit();
}

// Marquer le message du manager comme lu (si existant et pas encore lu)
if(!empty($incident['commentaire_manager']) && $incident['message_manager_lu'] == 0) {
    $stmt = $conn->prepare("UPDATE signalements SET message_manager_lu = 1 WHERE id = ?");
    $stmt->execute([$id]);
    $incident['message_manager_lu'] = 1;
}

// Traitement de la réponse du superviseur
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reponse'])) {
    $reponse = trim($_POST['reponse']);
    if(!empty($reponse)) {
        $stmt = $conn->prepare("UPDATE signalements SET reponse_superviseur = ? WHERE id = ?");
        $stmt->execute([$reponse, $id]);
        $_SESSION['flash_message'] = "Votre réponse a été envoyée.";
        header("Location: message.php?id=$id");
        exit();
    }
}

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gradient-to-br from-slate-800 to-blue-900 min-h-screen p-6">
    <div class="max-w-3xl mx-auto">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            <div class="bg-gradient-to-r from-blue-800 to-indigo-800 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <div class="bg-white/20 p-1 rounded-lg"><img src="../assets/images/logo.jpg" alt="IN WAN" class="h-8 w-auto"></div>
                    <div><h2 class="text-white font-bold"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2><p class="text-indigo-100 text-xs">Superviseur • <?php echo $date_jour; ?></p></div>
                </div>
                <a href="dashboard.php" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full text-sm transition">← Retour</a>
            </div>
            <div class="p-6">
                <?php if(isset($_SESSION['flash_message'])): ?>
                    <div class="bg-green-50 border-l-4 border-green-500 text-green-700 p-4 rounded-lg mb-6 text-sm">
                        <?php echo $_SESSION['flash_message']; unset($_SESSION['flash_message']); ?>
                    </div>
                <?php endif; ?>
                <div class="mb-6 pb-3 border-b border-gray-200">
                    <h1 class="text-2xl font-bold text-gray-800">Message</h1>
                    <p class="text-gray-500 text-sm mt-1">Incident <?php echo $incident['id']; ?> – <?php echo htmlspecialchars($incident['equipement']); ?></p>
                </div>

                <div class="space-y-4 mb-8 max-h-[400px] overflow-y-auto p-2 bg-gray-50 rounded-xl">
                    <?php if(!empty($incident['commentaire_manager'])): ?>
                        <div class="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-lg">
                            <div class="flex justify-between items-center text-xs text-blue-600 mb-1">
                                <span class="font-semibold">👔 Manager</span>
                                <span><?php echo date('d/m/Y H:i', strtotime($incident['date_validation_manager'] ?? $incident['date_signalement'])); ?></span>
                            </div>
                            <p class="text-gray-700"><?php echo nl2br(htmlspecialchars($incident['commentaire_manager'])); ?></p>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-gray-400 italic py-6">💬 Aucun message du manager pour cet incident.</div>
                    <?php endif; ?>

                    <?php if(!empty($incident['reponse_superviseur'])): ?>
                        <div class="bg-green-50 border-l-4 border-green-500 p-4 rounded-lg">
                            <div class="flex justify-between items-center text-xs text-green-600 mb-1">
                                <span class="font-semibold">💬 Vous (superviseur)</span>
                                <span><?php echo date('d/m/Y H:i', strtotime($incident['date_affectation_superviseur'] ?? $incident['date_signalement'])); ?></span>
                            </div>
                            <p class="text-gray-700"><?php echo nl2br(htmlspecialchars($incident['reponse_superviseur'])); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="border-t border-gray-200 pt-6">
                    <form method="POST">
                        <label class="block text-gray-700 font-semibold mb-2">Répondre au manager</label>
                        <textarea name="reponse" rows="3" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500" placeholder="Écrivez votre message ici..."></textarea>
                        <div class="flex justify-end mt-3">
                            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium">📨 Envoyer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>