<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'chef_equipe') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

// Récupérer tous les incidents avec un statut qui nécessite l'action du chef
// On prend ceux qui sont en 'en_attente_chef' ou encore 'en_attente' (ancien)
$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.statut IN ('en_attente_chef', 'en_attente')
    ORDER BY s.date_signalement DESC
");
$stmt->execute();
$incidents = $stmt->fetchAll();

// Statistiques
$agent_ids = array_column($stmt->fetchAll(), 'id'); // simple pour le total, mais on va faire autrement
// Calcul des stats globales (sur tous les incidents de l'équipe)
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM signalements");
$stmt->execute();
$total = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as a_valider FROM signalements WHERE statut IN ('en_attente_chef', 'en_attente')");
$stmt->execute();
$a_valider = $stmt->fetch()['a_valider'];

$stmt = $conn->prepare("SELECT COUNT(*) as en_cours FROM signalements WHERE statut IN ('valide_chef', 'transmis_manager', 'valide_manager', 'affectation_superviseur', 'en_cours')");
$stmt->execute();
$en_cours = $stmt->fetch()['en_cours'];

$stmt = $conn->prepare("SELECT COUNT(*) as termines FROM signalements WHERE statut = 'termine'");
$stmt->execute();
$termines = $stmt->fetch()['termines'];

// Pour chaque incident, récupérer les médias
foreach($incidents as $key => $inc) {
    $stmt = $conn->prepare("SELECT * FROM photos WHERE signalement_id = ?");
    $stmt->execute([$inc['id']]);
    $incidents[$key]['medias'] = $stmt->fetchAll();
}

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chef d'équipe - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-900 to-blue-900 min-h-screen p-6">
    <div class="max-w-5xl mx-auto">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <!-- En-tête -->
            <div class="bg-gradient-to-r from-blue-900 to-blue-700 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-10 w-auto bg-white rounded-lg p-1">
                    <div>
                        <h2 class="text-white font-bold text-lg"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2>
                        <p class="text-blue-100 text-sm">Chef d'équipe • <?php echo $date_jour; ?></p>
                    </div>
                </div>
                <a href="../logout.php" class="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-full text-sm">Déconnexion</a>
            </div>

            <div class="p-6">
                <!-- Statistiques -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                    <div class="bg-blue-50 rounded-xl p-4 text-center border-l-4 border-blue-600">
                        <div class="text-2xl">📊</div>
                        <div class="text-xs text-gray-500 uppercase">Total incidents</div>
                        <div class="text-2xl font-bold text-blue-700"><?php echo $total; ?></div>
                    </div>
                    <div class="bg-yellow-50 rounded-xl p-4 text-center border-l-4 border-yellow-600">
                        <div class="text-2xl">⏳</div>
                        <div class="text-xs text-gray-500 uppercase">À valider</div>
                        <div class="text-2xl font-bold text-yellow-600"><?php echo $a_valider; ?></div>
                    </div>
                    <div class="bg-orange-50 rounded-xl p-4 text-center border-l-4 border-orange-500">
                        <div class="text-2xl">🔄</div>
                        <div class="text-xs text-gray-500 uppercase">En cours</div>
                        <div class="text-2xl font-bold text-orange-500"><?php echo $en_cours; ?></div>
                    </div>
                    <div class="bg-green-50 rounded-xl p-4 text-center border-l-4 border-green-600">
                        <div class="text-2xl">✅</div>
                        <div class="text-xs text-gray-500 uppercase">Terminés</div>
                        <div class="text-2xl font-bold text-green-600"><?php echo $termines; ?></div>
                    </div>
                </div>

                <!-- Liste des incidents à traiter -->
                <div class="flex justify-between items-center mb-4">
                    <h1 class="text-xl font-bold text-gray-800">📋 Incidents à traiter</h1>
                    <span class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm"><?php echo count($incidents); ?> en attente</span>
                </div>

                <?php if(count($incidents) > 0): ?>
                    <div class="space-y-5">
                        <?php foreach($incidents as $inc): ?>
                            <div class="border rounded-xl p-4 bg-gray-50">
                                <div class="flex justify-between items-start flex-wrap gap-2">
                                    <div>
                                        <span class="font-bold text-blue-900"><?php echo $inc['id']; ?></span>
                                        <span class="text-gray-500 mx-2">|</span>
                                        <span class="font-semibold"><?php echo htmlspecialchars($inc['equipement']); ?></span>
                                    </div>
                                    <span class="text-sm text-gray-500"><?php echo date('d/m H:i', strtotime($inc['date_signalement'])); ?></span>
                                </div>
                                <div class="mt-2 text-sm text-gray-600">Agent: <?php echo htmlspecialchars($inc['agent_nom']); ?></div>
                                <div class="text-sm text-gray-600">Type: <?php echo htmlspecialchars($inc['type_panne']); ?></div>
                                <div class="text-sm text-gray-600">Urgence: <?php echo $inc['urgence']; ?></div>
                                <div class="mt-2 text-gray-700"><?php echo nl2br(htmlspecialchars(substr($inc['description'], 0, 100))); ?>...</div>
                                
                                <!-- Boutons d'action -->
                                <div class="flex gap-3 mt-4">
                                    <a href="detail.php?id=<?php echo $inc['id']; ?>" class="bg-gray-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-gray-700">📄 Détails</a>
                                    <a href="valider.php?id=<?php echo $inc['id']; ?>&action=valider" class="bg-green-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-green-700" onclick="return confirm('Valider et transmettre ?')">✅ Valider & Transmettre</a>
                                    <a href="valider.php?id=<?php echo $inc['id']; ?>&action=refuser" class="bg-red-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-red-700" onclick="return confirm('Refuser cet incident ?')">❌ Refuser</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-10 bg-gray-50 rounded-xl">
                        <div class="text-5xl mb-2">✅</div>
                        <p class="text-gray-500">Aucun incident à traiter pour le moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>