<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'superviseur') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$incident_id = isset($_POST['incident_id']) ? (int)$_POST['incident_id'] : 0;
$reponse = trim($_POST['reponse']);

if($incident_id && !empty($reponse)) {
    $stmt = $conn->prepare("UPDATE signalements SET reponse_superviseur = ? WHERE id = ?");
    $stmt->execute([$reponse, $incident_id]);
    $_SESSION['flash_message'] = "✅ Réponse envoyée au manager.";
}
header('Location: dashboard.php');
exit();
?>