<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'agent') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$signalement_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($signalement_id <= 0) {
    header('Location: dashboard.php');
    exit();
}

$stmt = $conn->prepare("SELECT * FROM signalements WHERE id = ? AND agent_id = ?");
$stmt->execute([$signalement_id, $_SESSION['user_id']]);
$signalement = $stmt->fetch();
if(!$signalement) {
    header('Location: dashboard.php');
    exit();
}

$stmt = $conn->prepare("SELECT COUNT(*) as nb FROM photos WHERE signalement_id = ?");
$stmt->execute([$signalement_id]);
$nb_photos = $stmt->fetch()['nb'];

if($signalement['statut'] == 'en_attente') {
    $stmt = $conn->prepare("UPDATE signalements SET statut = 'en_attente_chef' WHERE id = ?");
    $stmt->execute([$signalement_id]);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Inter', sans-serif; }
        body {
            background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
            min-height: 100vh;
            padding: 24px;
        }
        .confirmation-card {
            background: white;
            border-radius: 28px;
            box-shadow: 0 20px 35px -10px rgba(0,0,0,0.2);
            max-width: 550px;
            margin: 0 auto;
            overflow: hidden;
        }
        .btn-primary {
            background: #1e3a8a;
            transition: all 0.2s;
        }
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
        }
    </style>
</head>
<body>
    <div class="confirmation-card">
        <!-- En-tête minimal -->
        <div class="bg-gradient-to-r from-[#1e3a8a] to-[#2563eb] px-6 py-3 flex justify-between items-center">
            <div class="flex items-center gap-2">
                <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-7 w-auto bg-white rounded-lg p-0.5">
                <span class="text-white font-medium text-sm">IN WAN</span>
            </div>
            <a href="dashboard.php" class="text-white/80 hover:text-white text-xs">← Accueil</a>
        </div>
        
        <!-- Corps centré -->
        <div class="p-6 text-center">
            <!-- Icône succès -->
            <div class="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg class="w-7 h-7 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                </svg>
            </div>
            
            <h2 class="text-xl font-semibold text-gray-800 mb-1">Signalement envoyé !</h2>
            <p class="text-gray-500 text-sm mb-5">Votre demande a été transmise</p>
            
            <!-- Infos clés -->
            <div class="bg-gray-50 rounded-xl p-4 text-left mb-5">
                <div class="flex justify-between items-center mb-2 pb-2 border-b border-gray-200">
                    <span class="text-gray-500 text-sm">Référence</span>
                    <span class="font-semibold text-gray-800">#<?php echo $signalement['id']; ?></span>
                </div>
                <div class="flex justify-between items-center mb-2 pb-2 border-b border-gray-200">
                    <span class="text-gray-500 text-sm">Équipement</span>
                    <span class="font-medium text-gray-700 text-sm"><?php echo htmlspecialchars($signalement['equipement']); ?></span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-500 text-sm">Preuves</span>
                    <span class="font-medium text-gray-700 text-sm"><?php echo $nb_photos; ?> fichier(s)</span>
                </div>
            </div>
            
            <!-- Personnes notifiées -->
            <div class="text-left mb-5">
                <p class="text-xs text-gray-400 uppercase tracking-wide mb-2">Notifiés</p>
                <div class="flex flex-wrap gap-2">
                    <span class="bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded-full">👷 Chef</span>
                    <span class="bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded-full">👨‍💼 Superviseur</span>
                    <span class="bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded-full">👔 Manager</span>
                </div>
            </div>
            
            <!-- Bouton -->
            <a href="dashboard.php" class="btn-primary block text-white text-center py-2.5 rounded-xl text-sm font-medium">
                Retour au tableau de bord
            </a>
        </div>
    </div>
</body>
</html>