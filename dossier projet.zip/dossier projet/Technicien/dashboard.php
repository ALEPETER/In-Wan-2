<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'technicien') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$tech_id = $_SESSION['user_id'];

// Interventions à démarrer (statut = affectation_superviseur)
$stmt = $conn->prepare("
    SELECT s.*, i.id as intervention_id
    FROM signalements s
    JOIN interventions i ON s.id = i.signalement_id
    WHERE i.technicien_id = ? AND s.statut = 'affectation_superviseur'
    ORDER BY s.date_signalement DESC
");
$stmt->execute([$tech_id]);
$a_faire = $stmt->fetchAll();

// Interventions en cours (statut = en_cours)
$stmt = $conn->prepare("
    SELECT s.*, i.id as intervention_id, i.date_debut
    FROM signalements s
    JOIN interventions i ON s.id = i.signalement_id
    WHERE i.technicien_id = ? AND s.statut = 'en_cours'
    ORDER BY i.date_debut DESC
");
$stmt->execute([$tech_id]);
$en_cours = $stmt->fetchAll();

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technicien - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gradient-to-br from-slate-800 to-blue-900 min-h-screen p-6">
    <div class="max-w-6xl mx-auto">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            <div class="bg-gradient-to-r from-blue-800 to-indigo-800 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <div class="bg-white/20 p-1 rounded-lg"><img src="../assets/images/logo.jpg" alt="IN WAN" class="h-8 w-auto"></div>
                    <div><h2 class="text-white font-bold"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2><p class="text-indigo-100 text-xs">Technicien • <?php echo $date_jour; ?></p></div>
                </div>
                <a href="../logout.php" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full text-sm transition">Déconnexion</a>
            </div>

            <div class="p-6">
                <?php if(isset($_SESSION['flash_message'])): ?>
                    <div class="bg-green-50 border-l-4 border-green-500 text-green-700 p-4 rounded-lg mb-6 text-sm">
                        <?php echo $_SESSION['flash_message']; unset($_SESSION['flash_message']); ?>
                    </div>
                <?php endif; ?>

                <!-- Interventions à démarrer -->
                <div class="mb-10">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-bold text-gray-800 flex items-center gap-2">
                            <span class="bg-blue-100 p-1 rounded-lg">🔧</span> Interventions à démarrer
                        </h2>
                        <span class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-semibold"><?php echo count($a_faire); ?></span>
                    </div>
                    <?php if(count($a_faire) > 0): ?>
                        <div class="grid grid-cols-1 gap-4">
                            <?php foreach($a_faire as $inc): ?>
                                <div class="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md transition">
                                    <div class="flex flex-wrap justify-between items-start gap-2">
                                        <div>
                                            <span class="font-bold text-blue-900"><?php echo $inc['id']; ?></span>
                                            <span class="text-gray-500 mx-2">|</span>
                                            <span class="font-semibold"><?php echo htmlspecialchars($inc['equipement']); ?></span>
                                        </div>
                                        <span class="text-sm text-gray-500"><?php echo date('d/m H:i', strtotime($inc['date_signalement'])); ?></span>
                                    </div>
                                    <div class="mt-2 text-sm text-gray-600">Type: <?php echo htmlspecialchars($inc['type_panne']); ?> • Urgence: <?php echo $inc['urgence']; ?></div>
                                    <div class="text-gray-700 text-sm mt-2 line-clamp-2"><?php echo nl2br(htmlspecialchars(substr($inc['description'], 0, 100))); ?>...</div>
                                    <div class="flex gap-3 mt-4 pt-3 border-t border-gray-100">
                                        <a href="detail.php?id=<?php echo $inc['id']; ?>" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition">📄 Détails</a>
                                        <a href="demarrer.php?id=<?php echo $inc['id']; ?>" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition" onclick="return confirm('Démarrer cette intervention ?')">🚀 Démarrer</a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="bg-gray-50 rounded-xl p-8 text-center text-gray-500">✅ Aucune intervention à démarrer.</div>
                    <?php endif; ?>
                </div>

                <!-- Interventions en cours -->
                <div>
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-bold text-gray-800 flex items-center gap-2">
                            <span class="bg-orange-100 p-1 rounded-lg">⏳</span> Interventions en cours
                        </h2>
                        <span class="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-semibold"><?php echo count($en_cours); ?></span>
                    </div>
                    <?php if(count($en_cours) > 0): ?>
                        <div class="grid grid-cols-1 gap-4">
                            <?php foreach($en_cours as $inc): ?>
                                <div class="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md transition">
                                    <div class="flex flex-wrap justify-between items-start gap-2">
                                        <div>
                                            <span class="font-bold text-blue-900"><?php echo $inc['id']; ?></span>
                                            <span class="text-gray-500 mx-2">|</span>
                                            <span class="font-semibold"><?php echo htmlspecialchars($inc['equipement']); ?></span>
                                        </div>
                                        <span class="text-sm text-gray-500">Démarré le <?php echo date('d/m H:i', strtotime($inc['date_debut'])); ?></span>
                                    </div>
                                    <div class="mt-2 text-sm text-gray-600">Type: <?php echo htmlspecialchars($inc['type_panne']); ?></div>
                                    <div class="flex gap-3 mt-4 pt-3 border-t border-gray-100">
                                        <a href="detail.php?id=<?php echo $inc['id']; ?>" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition">📄 Détails</a>
                                        <a href="terminer.php?id=<?php echo $inc['id']; ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition">✅ Terminer</a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="bg-gray-50 rounded-xl p-8 text-center text-gray-500">🕒 Aucune intervention en cours.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>