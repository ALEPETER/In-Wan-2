<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'manager') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

// Récupérer les incidents en attente de validation (transmis par superviseur)
$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.statut = 'transmis_manager'
    ORDER BY s.date_signalement DESC
");
$stmt->execute();
$incidents = $stmt->fetchAll();

foreach($incidents as $key => $inc) {
    $stmt = $conn->prepare("SELECT * FROM photos WHERE signalement_id = ?");
    $stmt->execute([$inc['id']]);
    $incidents[$key]['medias'] = $stmt->fetchAll();
}

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-800 to-blue-900 min-h-screen p-6">
    <div class="max-w-6xl mx-auto">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            <!-- En-tête -->
            <div class="bg-gradient-to-r from-blue-800 to-indigo-800 px-8 py-5 flex justify-between items-center">
                <div class="flex items-center gap-4">
                    <div class="bg-white/20 p-2 rounded-xl">
                        <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-10 w-auto">
                    </div>
                    <div>
                        <h2 class="text-white font-bold text-xl tracking-tight"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2>
                        <p class="text-indigo-100 text-sm font-light">Manager • <?php echo $date_jour; ?></p>
                    </div>
                </div>
                <div class="flex gap-3">
                    <a href="statistiques.php" class="bg-white/10 hover:bg-white/20 text-white px-5 py-2 rounded-full text-sm font-medium transition flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                        Statistiques
                    </a>
                    <a href="../logout.php" class="bg-white/10 hover:bg-white/20 text-white px-5 py-2 rounded-full text-sm font-medium transition">Déconnexion</a>
                </div>
            </div>

            <div class="p-8">
                <?php if(isset($_SESSION['flash_message'])): ?>
                    <div class="bg-green-50 border-l-4 border-green-500 text-green-700 p-4 rounded-lg mb-6 text-sm">
                        <?php echo $_SESSION['flash_message']; unset($_SESSION['flash_message']); ?>
                    </div>
                <?php endif; ?>

                <div class="flex justify-between items-center mb-6">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-800 flex items-center gap-2">
                            <span class="bg-yellow-100 p-1 rounded-lg">📋</span>
                            Décisions stratégiques
                        </h1>
                        <p class="text-gray-500 text-sm mt-1">Incidents transmis par le superviseur, en attente de validation</p>
                    </div>
                    <span class="bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold shadow-sm"><?php echo count($incidents); ?> en attente</span>
                </div>

                <?php if(count($incidents) > 0): ?>
                    <div class="grid grid-cols-1 gap-6">
                        <?php foreach($incidents as $inc): ?>
                            <div class="bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden">
                                <div class="p-5">
                                    <div class="flex flex-wrap justify-between items-start gap-3 mb-3">
                                        <div class="flex items-center gap-2">
                                            <span class="text-sm font-mono bg-blue-50 text-blue-700 px-2 py-1 rounded-lg"> <?php echo $inc['id']; ?></span>
                                            <span class="font-semibold text-gray-800"><?php echo htmlspecialchars($inc['equipement']); ?></span>
                                            <span class="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded-full">Agent: <?php echo htmlspecialchars($inc['agent_nom']); ?></span>
                                        </div>
                                        <div class="flex items-center gap-2">
                                            <?php
                                            $urgenceColors = [
                                                'faible' => 'bg-green-100 text-green-700',
                                                'moyen' => 'bg-yellow-100 text-yellow-700',
                                                'urgent' => 'bg-orange-100 text-orange-700',
                                                'critique' => 'bg-red-100 text-red-700'
                                            ];
                                            $urgenceClass = $urgenceColors[$inc['urgence']] ?? 'bg-gray-100 text-gray-700';
                                            ?>
                                            <span class="px-2 py-1 rounded-full text-xs font-medium <?php echo $urgenceClass; ?>">
                                                🔥 <?php echo ucfirst($inc['urgence']); ?>
                                            </span>
                                            <span class="text-xs text-gray-400">📅 <?php echo date('d/m H:i', strtotime($inc['date_signalement'])); ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="text-gray-600 text-sm mb-3 line-clamp-2">
                                        <?php echo nl2br(htmlspecialchars(substr($inc['description'], 0, 120))); ?>...
                                    </div>
                                    
                                    <?php if(count($inc['medias']) > 0): ?>
                                        <div class="flex items-center gap-2 mb-3">
                                            <span class="text-xs text-gray-500">📎 Pièces jointes :</span>
                                            <div class="flex gap-1">
                                                <?php foreach(array_slice($inc['medias'], 0, 3) as $media): ?>
                                                    <a href="<?php echo $media['chemin_photo']; ?>" target="_blank" class="text-blue-500 text-xs underline"><?php echo $media['type_media'] == 'photo' ? '📷' : '🎥'; ?></a>
                                                <?php endforeach; ?>
                                                <?php if(count($inc['medias']) > 3): ?>
                                                    <span class="text-xs text-gray-400">+<?php echo count($inc['medias']) - 3; ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="flex flex-wrap gap-3 mt-4 pt-3 border-t border-gray-100">
                                        <a href="detail.php?id=<?php echo $inc['id']; ?>" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition flex items-center gap-1">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                            Détails
                                        </a>
                                        <a href="valider.php?id=<?php echo $inc['id']; ?>" class="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition shadow-sm flex items-center gap-1">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                            Valider
                                        </a>
                                        <a href="rejeter.php?id=<?php echo $inc['id']; ?>" class="bg-red-100 hover:bg-red-200 text-red-700 px-5 py-2 rounded-lg text-sm font-medium transition flex items-center gap-1" onclick="return confirm('Rejeter cet incident ?')">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                                            Rejeter
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="bg-gray-50 rounded-xl p-12 text-center">
                        <div class="text-5xl mb-4 opacity-50">📭</div>
                        <h3 class="text-xl font-semibold text-gray-700 mb-1">Aucune demande en attente</h3>
                        <p class="text-gray-400 max-w-md mx-auto">Les incidents validés par le superviseur apparaîtront ici pour approbation.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>