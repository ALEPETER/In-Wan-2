<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'superviseur') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

// Incidents à transmettre au manager
$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.statut = 'valide_chef'
    ORDER BY s.date_signalement DESC
");
$stmt->execute();
$a_transmettre = $stmt->fetchAll();

// Incidents à affecter (validés manager)
$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.statut = 'valide_manager'
    ORDER BY s.date_signalement DESC
");
$stmt->execute();
$a_affecter = $stmt->fetchAll();

// Liste des techniciens
$stmt = $conn->prepare("SELECT id, nom_complet FROM utilisateurs WHERE role = 'technicien'");
$stmt->execute();
$techniciens = $stmt->fetchAll();

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Superviseur - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-900 to-blue-900 min-h-screen p-6">
    <div class="max-w-6xl mx-auto">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="bg-gradient-to-r from-blue-900 to-blue-700 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-10 w-auto bg-white rounded-lg p-1">
                    <div>
                        <h2 class="text-white font-bold text-lg"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2>
                        <p class="text-blue-100 text-sm">Superviseur • <?php echo $date_jour; ?></p>
                    </div>
                </div>
                <a href="../logout.php" class="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-full text-sm">Déconnexion</a>
            </div>

            <div class="p-6">
                <!-- Section 1 : Transmettre au manager -->
                <div class="mb-10">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-bold text-gray-800">📤 Incidents à transmettre au manager</h2>
                        <span class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm"><?php echo count($a_transmettre); ?></span>
                    </div>
                    <?php if(count($a_transmettre) > 0): ?>
                        <?php foreach($a_transmettre as $inc): ?>
                            <div class="border rounded-xl p-4 bg-gray-50 mb-3">
                                <div><strong>#<?php echo $inc['id']; ?></strong> | <?php echo htmlspecialchars($inc['equipement']); ?> (Agent: <?php echo htmlspecialchars($inc['agent_nom']); ?>)</div>
                                <div class="text-sm text-gray-600">Type: <?php echo $inc['type_panne']; ?> • Urgence: <?php echo $inc['urgence']; ?></div>
                                <div class="flex gap-2 mt-2">
                                    <a href="detail.php?id=<?php echo $inc['id']; ?>" class="bg-gray-600 text-white px-3 py-1 rounded text-sm">Détails</a>
                                    <a href="transmettre.php?id=<?php echo $inc['id']; ?>" class="bg-blue-600 text-white px-3 py-1 rounded text-sm" onclick="return confirm('Transmettre au manager ?')">Transmettre</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="bg-gray-50 rounded-xl p-6 text-center">✅ Aucun incident à transmettre</div>
                    <?php endif; ?>
                </div>

                <!-- Section 2 : Affecter un technicien -->
                <div>
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-bold text-gray-800">🔧 Incidents à affecter (validés manager)</h2>
                        <span class="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm"><?php echo count($a_affecter); ?></span>
                    </div>
                    <?php if(count($a_affecter) > 0): ?>
                        <?php foreach($a_affecter as $inc): ?>
                            <div class="border rounded-xl p-4 bg-gray-50 mb-3">
                                <div><strong>#<?php echo $inc['id']; ?></strong> | <?php echo htmlspecialchars($inc['equipement']); ?> (Agent: <?php echo htmlspecialchars($inc['agent_nom']); ?>)</div>
                                <div class="text-sm text-gray-600">Type: <?php echo $inc['type_panne']; ?> • Urgence: <?php echo $inc['urgence']; ?></div>
                                <form action="affecter.php" method="POST" class="mt-3 flex items-center gap-2 flex-wrap">
                                    <input type="hidden" name="incident_id" value="<?php echo $inc['id']; ?>">
                                    <select name="technicien_id" required class="border rounded px-2 py-1 text-sm">
                                        <option value="">-- Choisir un technicien --</option>
                                        <?php foreach($techniciens as $tech): ?>
                                            <option value="<?php echo $tech['id']; ?>"><?php echo htmlspecialchars($tech['nom_complet']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <a href="detail.php?id=<?php echo $inc['id']; ?>" class="bg-gray-600 text-white px-3 py-1 rounded text-sm">Détails</a>
                                    <button type="submit" class="bg-green-600 text-white px-4 py-1 rounded text-sm" onclick="return confirm('Affecter ce technicien ?')">Affecter</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="bg-gray-50 rounded-xl p-6 text-center">✅ Aucun incident à affecter</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>