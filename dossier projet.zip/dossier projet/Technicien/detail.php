<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'technicien') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.id = ?
");
$stmt->execute([$id]);
$incident = $stmt->fetch();

if(!$incident) {
    header('Location: dashboard.php');
    exit();
}

$stmt = $conn->prepare("SELECT * FROM photos WHERE signalement_id = ?");
$stmt->execute([$id]);
$medias = $stmt->fetchAll();

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détail incident - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gradient-to-br from-slate-800 to-blue-900 min-h-screen p-6">
    <div class="max-w-3xl mx-auto">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            <div class="bg-gradient-to-r from-blue-800 to-indigo-800 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <div class="bg-white/20 p-1 rounded-lg"><img src="../assets/images/logo.jpg" alt="IN WAN" class="h-8 w-auto"></div>
                    <div><h2 class="text-white font-bold"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2><p class="text-indigo-100 text-xs">Technicien • <?php echo $date_jour; ?></p></div>
                </div>
                <a href="dashboard.php" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full text-sm transition">← Retour</a>
            </div>
            <div class="p-6">
                <div class="flex justify-between items-start flex-wrap gap-4 mb-6 pb-3 border-b border-gray-100">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-800">Incident <?php echo $incident['id']; ?></h1>
                        <p class="text-gray-500 text-sm mt-1"><?php echo htmlspecialchars($incident['equipement']); ?></p>
                    </div>
                    <div>
                        <?php
                        $badgeClass = '';
                        if($incident['statut'] == 'affectation_superviseur') $badgeClass = 'bg-blue-100 text-blue-700';
                        elseif($incident['statut'] == 'en_cours') $badgeClass = 'bg-yellow-100 text-yellow-700';
                        elseif($incident['statut'] == 'termine') $badgeClass = 'bg-green-100 text-green-700';
                        else $badgeClass = 'bg-gray-100 text-gray-700';
                        ?>
                        <span class="px-3 py-1 rounded-full text-xs font-medium <?php echo $badgeClass; ?>"><?php echo str_replace('_', ' ', $incident['statut']); ?></span>
                    </div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div class="bg-gray-50 rounded-lg p-3"><div class="text-xs text-gray-500 uppercase">Type de panne</div><div class="font-medium"><?php echo htmlspecialchars($incident['type_panne']); ?></div></div>
                    <div class="bg-gray-50 rounded-lg p-3"><div class="text-xs text-gray-500 uppercase">Urgence</div><div class="font-medium <?php echo $incident['urgence'] == 'critique' ? 'text-red-600' : ($incident['urgence'] == 'urgent' ? 'text-orange-600' : ($incident['urgence'] == 'moyen' ? 'text-yellow-600' : 'text-green-600')); ?>"><?php echo ucfirst($incident['urgence']); ?></div></div>
                    <div class="bg-gray-50 rounded-lg p-3"><div class="text-xs text-gray-500 uppercase">Agent</div><div class="font-medium"><?php echo htmlspecialchars($incident['agent_nom']); ?></div></div>
                    <div class="bg-gray-50 rounded-lg p-3"><div class="text-xs text-gray-500 uppercase">Date signalement</div><div class="font-medium"><?php echo date('d/m/Y H:i', strtotime($incident['date_signalement'])); ?></div></div>
                </div>
                <div class="mb-6"><div class="text-xs text-gray-500 uppercase mb-1">Description</div><div class="bg-gray-50 rounded-lg p-4 text-gray-700 text-sm"><?php echo nl2br(htmlspecialchars($incident['description'])); ?></div></div>
                <?php if(count($medias) > 0): ?>
                    <div class="mb-6"><div class="text-xs text-gray-500 uppercase mb-2">Preuves visuelles</div><div class="grid grid-cols-2 sm:grid-cols-3 gap-3"><?php foreach($medias as $m): ?><a href="<?php echo $m['chemin_photo']; ?>" target="_blank" class="block"><?php if($m['type_media'] == 'photo'): ?><img src="<?php echo $m['chemin_photo']; ?>" class="w-full h-28 object-cover rounded-lg shadow-sm"><?php else: ?><div class="w-full h-28 bg-gray-100 rounded-lg flex items-center justify-center text-3xl">🎥</div><?php endif; ?></a><?php endforeach; ?></div></div>
                <?php else: ?><div class="bg-gray-50 rounded-lg p-4 text-center text-gray-400 text-sm mb-6">📭 Aucune preuve jointe</div><?php endif; ?>
                <div class="flex flex-col sm:flex-row gap-3 pt-4 border-t">
                    <a href="dashboard.php" class="flex-1 text-center bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 rounded-lg text-sm font-medium transition">← Retour au tableau de bord</a>
                    <?php if($incident['statut'] == 'affectation_superviseur'): ?>
                        <a href="demarrer.php?id=<?php echo $incident['id']; ?>" class="flex-1 text-center bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg text-sm font-medium transition" onclick="return confirm('Démarrer cette intervention ?')">🚀 Démarrer</a>
                    <?php elseif($incident['statut'] == 'en_cours'): ?>
                        <a href="terminer.php?id=<?php echo $incident['id']; ?>" class="flex-1 text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg text-sm font-medium transition">✅ Terminer</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>