<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'agent') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $conn->prepare("SELECT * FROM signalements WHERE id = ? AND agent_id = ?");
$stmt->execute([$id, $_SESSION['user_id']]);
$signalement = $stmt->fetch();
if(!$signalement) {
    header('Location: dashboard.php');
    exit();
}

$stmt = $conn->prepare("SELECT * FROM photos WHERE signalement_id = ?");
$stmt->execute([$id]);
$medias = $stmt->fetchAll();

$date_jour = date('d/m/Y');

function getStatutClass($statut) {
    switch($statut) {
        case 'termine': return 'bg-green-100 text-green-700';
        case 'en_cours': return 'bg-yellow-100 text-yellow-600';
        case 'annule': return 'bg-red-100 text-red-600';
        default: return 'bg-blue-100 text-blue-700';
    }
}

function getStatutLibelle($statut) {
    switch($statut) {
        case 'en_attente_chef': return '⏳ En attente chef';
        case 'valide_chef': return '✅ Validé chef';
        case 'transmis_manager': return '📤 Transmis manager';
        case 'valide_manager': return '✅ Validé manager';
        case 'affectation_superviseur': return '🔧 En attente affectation';
        case 'en_cours': return '🔧 En cours';
        case 'termine': return '✅ Terminé';
        case 'annule': return '❌ Annulé';
        default: return $statut;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détail #<?php echo $signalement['id']; ?> - Kwetu</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: { primary: '#1e3a8a', primaryLight: '#3b82f6', primaryDark: '#172554' }
                }
            }
        }
    </script>
</head>
<body class="bg-gradient-to-br from-slate-900 to-blue-900 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <div class="bg-white rounded-2xl shadow-xl p-5">
            
            <!-- En-tête -->
            <div class="flex justify-between items-center mb-4 pb-3 border-b border-gray-100">
                <div class="flex items-center gap-2">
                    <div class="text-2xl">👤</div>
                    <div>
                        <div class="font-semibold text-gray-800"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></div>
                        <div class="text-xs text-gray-400"><?php echo $date_jour; ?></div>
                    </div>
                </div>
                <a href="dashboard.php" class="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm hover:bg-gray-200">Retour</a>
            </div>
            
            <!-- Titre et statut -->
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-bold text-gray-800">Signalement #<?php echo $signalement['id']; ?></h2>
                <span class="px-3 py-1 rounded-full text-xs font-semibold <?php echo getStatutClass($signalement['statut']); ?>">
                    <?php echo getStatutLibelle($signalement['statut']); ?>
                </span>
            </div>
            
            <!-- Informations -->
            <div class="space-y-2 mb-4">
                <div><span class="font-semibold text-gray-600 text-sm">📅 Date :</span> <span class="text-sm"><?php echo date('d/m/Y à H:i', strtotime($signalement['date_signalement'])); ?></span></div>
                <div><span class="font-semibold text-gray-600 text-sm">🏭 Équipement :</span> <span class="text-sm"><?php echo htmlspecialchars($signalement['equipement']); ?></span></div>
                <div><span class="font-semibold text-gray-600 text-sm">⚡ Type :</span> <span class="text-sm"><?php echo htmlspecialchars($signalement['type_panne']); ?></span></div>
                <div><span class="font-semibold text-gray-600 text-sm">🔥 Urgence :</span> <span class="text-sm"><?php echo $signalement['urgence']; ?></span></div>
                <div><span class="font-semibold text-gray-600 text-sm">📝 Description :</span> <span class="text-sm block bg-gray-50 p-2 rounded-lg mt-1"><?php echo nl2br(htmlspecialchars($signalement['description'])); ?></span></div>
            </div>
            
            <!-- Photos -->
            <?php if(count($medias) > 0): ?>
                <div class="mb-4">
                    <h3 class="font-semibold text-gray-700 text-sm mb-2">📸 Preuves visuelles</h3>
                    <div class="grid grid-cols-3 gap-2">
                        <?php foreach($medias as $m): ?>
                            <div class="bg-gray-100 rounded-xl overflow-hidden aspect-square">
                                <?php if($m['type_media'] == 'photo'): ?>
                                    <img src="<?php echo $m['chemin_photo']; ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <video src="<?php echo $m['chemin_photo']; ?>" class="w-full h-full object-cover"></video>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Chronologie -->
            <div class="bg-gray-50 rounded-xl p-3 mb-4">
                <h3 class="font-semibold text-gray-700 text-sm mb-2">📋 Chronologie</h3>
                <div class="space-y-1 text-xs text-gray-600">
                    <div>📤 <?php echo date('d/m H:i', strtotime($signalement['date_signalement'])); ?> - Signalement créé</div>
                    <?php if($signalement['statut'] != 'en_attente_chef'): ?>
                        <div>👷 Validation chef d'équipe</div>
                    <?php endif; ?>
                    <?php if(in_array($signalement['statut'], ['valide_manager','affectation_superviseur','en_cours','termine'])): ?>
                        <div>👔 Validation manager</div>
                    <?php endif; ?>
                    <?php if(in_array($signalement['statut'], ['en_cours','termine'])): ?>
                        <div>🔧 Intervention en cours</div>
                    <?php endif; ?>
                    <?php if($signalement['statut'] == 'termine'): ?>
                        <div>✅ Réparation terminée</div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Bouton annuler -->
            <?php if($signalement['statut'] != 'termine' && $signalement['statut'] != 'annule'): ?>
                <a href="annuler.php?id=<?php echo $signalement['id']; ?>" 
                   onclick="return confirm('Annuler ce signalement ?')"
                   class="block w-full text-center bg-red-50 text-red-600 py-2 rounded-xl text-sm hover:bg-red-100 transition">
                    ❌ Annuler le signalement
                </a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>