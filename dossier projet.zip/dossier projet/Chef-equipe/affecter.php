<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'superviseur') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$incident_id = isset($_POST['incident_id']) ? (int)$_POST['incident_id'] : 0;
$technicien_id = isset($_POST['technicien_id']) ? (int)$_POST['technicien_id'] : 0;

if($incident_id && $technicien_id) {
    $stmt = $conn->prepare("UPDATE signalements SET statut = 'affectation_superviseur', date_affectation_superviseur = NOW() WHERE id = ?");
    $stmt->execute([$incident_id]);
    
    $stmt = $conn->prepare("INSERT INTO interventions (signalement_id, technicien_id, superviseur_id, date_affectation) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$incident_id, $technicien_id, $_SESSION['user_id']]);
}
header('Location: dashboard.php');
exit();
?>