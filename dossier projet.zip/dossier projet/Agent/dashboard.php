<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'agent') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$agent_id = $_SESSION['user_id'];

// Statistiques (sans les annulés)
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM signalements WHERE agent_id = ? AND statut != 'annule'");
$stmt->execute([$agent_id]);
$total = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as encours FROM signalements WHERE agent_id = ? AND statut NOT IN ('termine', 'annule')");
$stmt->execute([$agent_id]);
$encours = $stmt->fetch()['encours'];

$stmt = $conn->prepare("SELECT COUNT(*) as termines FROM signalements WHERE agent_id = ? AND statut = 'termine'");
$stmt->execute([$agent_id]);
$termines = $stmt->fetch()['termines'];

// Récupérer les signalements non annulés
$stmt = $conn->prepare("SELECT * FROM signalements WHERE agent_id = ? AND statut != 'annule' ORDER BY date_signalement DESC LIMIT 10");
$stmt->execute([$agent_id]);
$signalements = $stmt->fetchAll();

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Inter', sans-serif; }
        body {
            background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
            min-height: 100vh;
            padding: 24px;
        }
        .glass-card { background: white; border-radius: 32px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); overflow: hidden; }
        .btn-primary { background: linear-gradient(135deg, #1e3a8a, #2563eb); transition: all 0.2s; }
        .btn-primary:hover { background: linear-gradient(135deg, #2563eb, #3b82f6); transform: translateY(-2px); box-shadow: 0 10px 20px -5px rgba(37,99,235,0.4); }
        .stat-card { transition: all 0.2s; border: 1px solid rgba(0,0,0,0.05); }
        .stat-card:hover { transform: translateY(-4px); box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); }
        .signalement-card { transition: all 0.2s; border-left: 3px solid transparent; }
        .signalement-card:hover { transform: translateX(4px); border-left-color: #1e3a8a; background-color: #f8fafc; }
    </style>
</head>
<body>
    <div class="max-w-6xl mx-auto">
        <div class="glass-card">
            <!-- Header -->
            <div class="bg-gradient-to-r from-[#1e3a8a] to-[#2563eb] px-8 py-5 flex justify-between items-center">
                <div class="flex items-center gap-4">
                    <div class="bg-white rounded-xl p-2"><img src="../assets/images/logo.jpg" alt="IN WAN" class="h-10 w-auto"></div>
                    <div><h2 class="text-white font-bold text-xl"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2><p class="text-blue-100 text-sm">Agent de maintenance • <?php echo $date_jour; ?></p></div>
                </div>
                <a href="../logout.php" class="bg-white/20 hover:bg-white/30 text-white px-5 py-2 rounded-full text-sm font-medium transition">🔓 Déconnexion</a>
            </div>
            
            <div class="p-8">
                <!-- Stats -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="stat-card bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-6 text-center"><div class="text-3xl mb-2">📊</div><div class="text-sm text-gray-500 uppercase font-semibold mb-1">Total</div><div class="text-4xl font-bold text-blue-800"><?php echo $total; ?></div></div>
                    <div class="stat-card bg-gradient-to-br from-amber-50 to-amber-100 rounded-2xl p-6 text-center"><div class="text-3xl mb-2">🔄</div><div class="text-sm text-gray-500 uppercase font-semibold mb-1">En cours</div><div class="text-4xl font-bold text-amber-600"><?php echo $encours; ?></div></div>
                    <div class="stat-card bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-6 text-center"><div class="text-3xl mb-2">✅</div><div class="text-sm text-gray-500 uppercase font-semibold mb-1">Terminés</div><div class="text-4xl font-bold text-green-600"><?php echo $termines; ?></div></div>
                </div>
                
                <!-- Bouton -->
                <a href="signaler.php" class="btn-primary block text-center text-white font-bold py-4 rounded-xl mb-8 text-lg">➕ SIGNALER UNE PANNE</a>
                
                <!-- Liste -->
                <div class="flex justify-between items-center mb-4"><h3 class="font-bold text-gray-800 text-lg">📋 Derniers signalements</h3><span class="text-xs text-gray-400 bg-gray-100 px-3 py-1 rounded-full"><?php echo count($signalements); ?></span></div>
                
                <?php if(count($signalements) > 0): ?>
                    <div class="space-y-3">
                        <?php foreach($signalements as $s): ?>
                            <div class="signalement-card bg-gray-50 rounded-xl p-4 border border-gray-100">
                                <div class="flex justify-between items-center flex-wrap gap-3">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 flex-wrap">
                                            <span class="font-bold text-gray-800"><?php echo $s['id']; ?></span>
                                            <span class="text-gray-600">•</span>
                                            <span class="font-medium text-gray-700"><?php echo htmlspecialchars($s['equipement']); ?></span>
                                        </div>
                                        <div class="text-sm text-gray-500 mt-1">
                                            <?php echo htmlspecialchars($s['type_panne']); ?> • <?php echo date('d/m/Y H:i', strtotime($s['date_signalement'])); ?>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <?php if($s['statut'] == 'termine'): ?>
                                            <span class="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">✅ Terminé</span>
                                        <?php elseif($s['statut'] == 'en_cours'): ?>
                                            <span class="bg-amber-100 text-amber-700 text-xs px-2 py-1 rounded-full">🔧 En cours</span>
                                        <?php else: ?>
                                            <span class="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full">⏳ En attente</span>
                                        <?php endif; ?>
                                        <a href="detail.php?id=<?php echo $s['id']; ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition">Détail</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="bg-gray-50 rounded-xl p-8 text-center text-gray-400">📭 Aucun signalement pour le moment</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>