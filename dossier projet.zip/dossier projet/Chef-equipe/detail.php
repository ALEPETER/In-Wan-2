<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'chef_equipe') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.id = ?
");
$stmt->execute([$id]);
$incident = $stmt->fetch();

if(!$incident) {
    header('Location: dashboard.php');
    exit();
}

$stmt = $conn->prepare("SELECT * FROM photos WHERE signalement_id = ?");
$stmt->execute([$id]);
$medias = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détail incident <?php echo $id; ?> - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-900 to-blue-900 min-h-screen p-6">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="bg-blue-900 px-6 py-4 flex justify-between items-center">
                <h1 class="text-white font-bold text-xl">Incident <?php echo $incident['id']; ?></h1>
                <a href="dashboard.php" class="bg-white/20 text-white px-4 py-2 rounded-lg text-sm">← Retour</a>
            </div>
            <div class="p-6 space-y-3">
                <p><strong>Équipement :</strong> <?php echo htmlspecialchars($incident['equipement']); ?></p>
                <p><strong>Agent :</strong> <?php echo htmlspecialchars($incident['agent_nom']); ?></p>
                <p><strong>Type :</strong> <?php echo htmlspecialchars($incident['type_panne']); ?></p>
                <p><strong>Urgence :</strong> <?php echo $incident['urgence']; ?></p>
                <p><strong>Date :</strong> <?php echo date('d/m/Y H:i', strtotime($incident['date_signalement'])); ?></p>
                <p><strong>Description :</strong><br><?php echo nl2br(htmlspecialchars($incident['description'])); ?></p>
                
                <?php if(count($medias) > 0): ?>
                    <div><strong>Preuves :</strong></div>
                    <div class="grid grid-cols-3 gap-2">
                        <?php foreach($medias as $m): ?>
                            <a href="<?php echo $m['chemin_photo']; ?>" target="_blank">
                                <?php if($m['type_media'] == 'photo'): ?>
                                    <img src="<?php echo $m['chemin_photo']; ?>" class="rounded-lg border h-24 w-full object-cover">
                                <?php else: ?>
                                    <div class="bg-gray-100 rounded-lg p-4 text-center">🎥 Vidéo</div>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-gray-400 italic">Aucune preuve jointe.</p>
                <?php endif; ?>
                
                <div class="flex gap-3 pt-4 border-t">
                    <a href="valider.php?id=<?php echo $incident['id']; ?>&action=valider" class="flex-1 bg-green-600 text-white text-center py-2 rounded-lg hover:bg-green-700">✅ Valider</a>
                    <a href="valider.php?id=<?php echo $incident['id']; ?>&action=refuser" class="flex-1 bg-red-600 text-white text-center py-2 rounded-lg hover:bg-red-700" onclick="return confirm('Refuser ?')">❌ Refuser</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>