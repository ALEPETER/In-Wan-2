<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'technicien') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$incident_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rapport = trim($_POST['rapport']);
    $pieces = trim($_POST['pieces']);
    if($incident_id) {
        $stmt = $conn->prepare("UPDATE signalements SET statut = 'termine', date_fin_intervention = NOW() WHERE id = ?");
        $stmt->execute([$incident_id]);
        $stmt = $conn->prepare("UPDATE interventions SET date_fin = NOW(), rapport_technicien = ?, pieces_utilisees = ? WHERE signalement_id = ?");
        $stmt->execute([$rapport, $pieces, $incident_id]);
        $_SESSION['flash_message'] = "Intervention terminée.";
        header('Location: dashboard.php');
        exit();
    }
}

$stmt = $conn->prepare("SELECT * FROM signalements WHERE id = ?");
$stmt->execute([$incident_id]);
$incident = $stmt->fetch();
if(!$incident) header('Location: dashboard.php');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminer intervention - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-900 to-blue-900 min-h-screen p-6">
    <div class="max-w-lg mx-auto">
        <div class="bg-white rounded-2xl shadow-xl p-6">
            <h1 class="text-xl font-bold text-gray-800 mb-2">Terminer l'intervention</h1>
            <p class="text-gray-600 mb-4">Incident <?php echo $incident['id']; ?> – <?php echo htmlspecialchars($incident['equipement']); ?></p>
            <form method="POST">
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Rapport</label>
                    <textarea name="rapport" rows="4" required class="w-full border rounded-lg px-3 py-2"></textarea>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Pièces utilisées</label>
                    <textarea name="pieces" rows="2" class="w-full border rounded-lg px-3 py-2"></textarea>
                </div>
                <div class="flex gap-3">
                    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">✅ Terminer</button>
                    <a href="dashboard.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">Annuler</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>