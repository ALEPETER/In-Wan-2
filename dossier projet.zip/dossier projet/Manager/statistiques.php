<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'manager') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

// Total incidents
$total = $conn->query("SELECT COUNT(*) FROM signalements")->fetchColumn();

// Incidents par statut
$statsStatut = [];
$stmt = $conn->query("SELECT statut, COUNT(*) as nb FROM signalements GROUP BY statut");
while($row = $stmt->fetch()) {
    $statsStatut[$row['statut']] = $row['nb'];
}

// Temps moyen de résolution (en minutes)
$stmt = $conn->query("SELECT AVG(TIMESTAMPDIFF(MINUTE, date_signalement, date_fin_intervention)) as moyenne FROM signalements WHERE statut = 'termine' AND date_fin_intervention IS NOT NULL");
$tempsMoyen = round($stmt->fetch()['moyenne'] ?? 0);

// Top 5 pannes récurrentes
$stmt = $conn->query("SELECT equipement, COUNT(*) as nb FROM signalements GROUP BY equipement ORDER BY nb DESC LIMIT 5");
$topPannes = $stmt->fetchAll();

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistiques - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-800 to-blue-900 min-h-screen p-6">
    <div class="max-w-6xl mx-auto">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            <!-- En-tête -->
            <div class="bg-gradient-to-r from-blue-800 to-indigo-800 px-8 py-5 flex justify-between items-center">
                <div class="flex items-center gap-4">
                    <div class="bg-white/20 p-2 rounded-xl">
                        <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-10 w-auto">
                    </div>
                    <div>
                        <h2 class="text-white font-bold text-xl"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2>
                        <p class="text-indigo-100 text-sm">Manager • <?php echo $date_jour; ?></p>
                    </div>
                </div>
                <a href="dashboard.php" class="bg-white/10 hover:bg-white/20 text-white px-5 py-2 rounded-full text-sm font-medium transition flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                    Retour
                </a>
            </div>

            <div class="p-8">
                <h1 class="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                    <span class="bg-indigo-100 p-1 rounded-lg">📊</span>
                    Tableau de bord stratégique
                </h1>

                <!-- KPI cards -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                    <div class="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-5 shadow-sm border border-blue-100">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-gray-500 text-sm font-medium uppercase tracking-wide">Total incidents</p>
                                <p class="text-4xl font-bold text-blue-700 mt-1"><?php echo $total; ?></p>
                            </div>
                            <div class="bg-blue-200/50 p-2 rounded-full">📋</div>
                        </div>
                    </div>
                    <div class="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-5 shadow-sm border border-green-100">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-gray-500 text-sm font-medium uppercase tracking-wide">Temps moyen résolution</p>
                                <p class="text-4xl font-bold text-green-700 mt-1"><?php echo $tempsMoyen; ?> <span class="text-lg font-normal">min</span></p>
                            </div>
                            <div class="bg-green-200/50 p-2 rounded-full">⏱️</div>
                        </div>
                    </div>
                    <div class="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-5 shadow-sm border border-purple-100">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-gray-500 text-sm font-medium uppercase tracking-wide">Taux de résolution</p>
                                <?php
                                $termines = $statsStatut['termine'] ?? 0;
                                $taux = $total > 0 ? round(($termines / $total) * 100) : 0;
                                ?>
                                <p class="text-4xl font-bold text-purple-700 mt-1"><?php echo $taux; ?>%</p>
                            </div>
                            <div class="bg-purple-200/50 p-2 rounded-full">✅</div>
                        </div>
                    </div>
                </div>

                <!-- Graphique statuts (version simplifiée) -->
                <div class="bg-gray-50 rounded-xl p-5 mb-8">
                    <h2 class="text-lg font-semibold text-gray-800 mb-3 flex items-center gap-2">📌 Répartition par statut</h2>
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                        <?php foreach($statsStatut as $statut => $nb): ?>
                            <div class="bg-white rounded-lg p-3 text-center shadow-sm border border-gray-100">
                                <div class="text-sm font-medium text-gray-600"><?php echo $statut; ?></div>
                                <div class="text-2xl font-bold text-indigo-600"><?php echo $nb; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Top pannes -->
                <div class="bg-gray-50 rounded-xl p-5">
                    <h2 class="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">🔥 Pannes récurrentes (top 5)</h2>
                    <div class="space-y-2">
                        <?php if(count($topPannes) > 0): ?>
                            <?php foreach($topPannes as $index => $panne): ?>
                                <div class="bg-white rounded-lg p-3 flex justify-between items-center shadow-sm">
                                    <div class="flex items-center gap-3">
                                        <span class="text-gray-400 font-mono text-sm">#<?php echo $index+1; ?></span>
                                        <span class="font-medium text-gray-800"><?php echo htmlspecialchars($panne['equipement']); ?></span>
                                    </div>
                                    <span class="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-semibold"><?php echo $panne['nb']; ?> incidents</span>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-6 text-gray-400">Aucune donnée disponible.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>