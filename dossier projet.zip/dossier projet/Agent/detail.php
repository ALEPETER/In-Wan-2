<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'agent') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Récupérer le signalement
$stmt = $conn->prepare("SELECT * FROM signalements WHERE id = ? AND agent_id = ?");
$stmt->execute([$id, $_SESSION['user_id']]);
$signalement = $stmt->fetch();

if(!$signalement) {
    header('Location: dashboard.php');
    exit();
}

// Récupérer les médias
$stmt = $conn->prepare("SELECT * FROM photos WHERE signalement_id = ?");
$stmt->execute([$id]);
$medias = $stmt->fetchAll();

$date_jour = date('d/m/Y');
$message = '';

// Traitement de l'annulation
if(isset($_GET['annuler']) && $_GET['annuler'] == 1) {
    $stmt = $conn->prepare("UPDATE signalements SET statut = 'annule' WHERE id = ?");
    $stmt->execute([$id]);
    $message = "Incident annulé avec succès.";
    // Recharger les données
    $stmt = $conn->prepare("SELECT * FROM signalements WHERE id = ?");
    $stmt->execute([$id]);
    $signalement = $stmt->fetch();
}

function getStatutBadge($statut) {
    switch($statut) {
        case 'termine': return '<span class="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">✅ Terminé</span>';
        case 'en_cours': return '<span class="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs font-medium">🔧 En cours</span>';
        case 'annule': return '<span class="bg-gray-200 text-gray-600 px-2 py-1 rounded-full text-xs font-medium">❌ Annulé</span>';
        default: return '<span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-medium">⏳ En attente</span>';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incident #<?php echo $signalement['id']; ?> - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-800 to-blue-900 min-h-screen p-6">
    <div class="max-w-3xl mx-auto">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            <!-- En-tête -->
            <div class="bg-gradient-to-r from-blue-800 to-indigo-800 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <div class="bg-white/20 p-1 rounded-lg">
                        <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-8 w-auto">
                    </div>
                    <div>
                        <h2 class="text-white font-bold"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2>
                        <p class="text-indigo-100 text-xs"><?php echo $date_jour; ?></p>
                    </div>
                </div>
                <a href="dashboard.php" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full text-sm transition">← Retour</a>
            </div>

            <div class="p-6">
                <!-- Message de confirmation -->
                <?php if($message): ?>
                    <div class="bg-green-50 border-l-4 border-green-500 text-green-700 p-3 rounded-lg mb-6 text-sm">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <!-- Titre et statut -->
                <div class="flex justify-between items-start flex-wrap gap-4 mb-6 pb-3 border-b border-gray-100">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-800">Incident <?php echo $signalement['id']; ?></h1>
                        <p class="text-gray-500 text-sm mt-1"><?php echo htmlspecialchars($signalement['equipement']); ?></p>
                    </div>
                    <div>
                        <?php echo getStatutBadge($signalement['statut']); ?>
                    </div>
                </div>

                <!-- Informations détaillées -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div class="bg-gray-50 rounded-lg p-3">
                        <div class="text-xs text-gray-500 uppercase">Type de panne</div>
                        <div class="font-medium text-gray-800"><?php echo htmlspecialchars($signalement['type_panne']); ?></div>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-3">
                        <div class="text-xs text-gray-500 uppercase">Niveau d'urgence</div>
                        <div class="font-medium <?php 
                            echo $signalement['urgence'] == 'critique' ? 'text-red-600' : 
                                ($signalement['urgence'] == 'urgent' ? 'text-orange-600' : 
                                ($signalement['urgence'] == 'moyen' ? 'text-yellow-600' : 'text-green-600')); 
                        ?>">
                            <?php echo ucfirst($signalement['urgence']); ?>
                        </div>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-3">
                        <div class="text-xs text-gray-500 uppercase">Date du signalement</div>
                        <div class="font-medium text-gray-800"><?php echo date('d/m/Y H:i', strtotime($signalement['date_signalement'])); ?></div>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-3">
                        <div class="text-xs text-gray-500 uppercase">Dernière mise à jour</div>
                        <div class="font-medium text-gray-800"><?php echo date('d/m/Y H:i', strtotime($signalement['date_signalement'])); ?></div>
                    </div>
                </div>

                <!-- Description -->
                <div class="mb-6">
                    <div class="text-xs text-gray-500 uppercase mb-1">Description complète</div>
                    <div class="bg-gray-50 rounded-lg p-4 text-gray-700 text-sm leading-relaxed">
                        <?php echo nl2br(htmlspecialchars($signalement['description'])); ?>
                    </div>
                </div>

                <!-- Preuves -->
                <?php if(count($medias) > 0): ?>
                    <div class="mb-6">
                        <div class="text-xs text-gray-500 uppercase mb-2">Preuves visuelles</div>
                        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                            <?php foreach($medias as $m): ?>
                                <a href="<?php echo $m['chemin_photo']; ?>" target="_blank" class="block">
                                    <?php if($m['type_media'] == 'photo'): ?>
                                        <img src="<?php echo $m['chemin_photo']; ?>" class="w-full h-28 object-cover rounded-lg shadow-sm hover:shadow-md transition">
                                    <?php else: ?>
                                        <div class="w-full h-28 bg-gray-100 rounded-lg flex items-center justify-center text-3xl hover:bg-gray-200 transition">
                                            🎥
                                        </div>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="bg-gray-50 rounded-lg p-4 text-center text-gray-400 text-sm mb-6">
                        📭 Aucune photo ou vidéo jointe
                    </div>
                <?php endif; ?>

                <!-- Boutons d'action -->
                <div class="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-100">
                    <a href="dashboard.php" class="flex-1 text-center bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 rounded-lg text-sm font-medium transition">
                        ← Retour au tableau de bord
                    </a>
                    <?php if($signalement['statut'] != 'termine' && $signalement['statut'] != 'annule'): ?>
                        <a href="detail.php?id=<?php echo $signalement['id']; ?>&annuler=1" 
                           class="flex-1 text-center bg-yellow-50 hover:bg-yellow-100 text-yellow-600 py-2 rounded-lg text-sm font-medium transition"
                           onclick="return confirm('Annuler cet incident ?')">
                            ❌ Annuler
                        </a>
                        <a href="supprimer.php?id=<?php echo $signalement['id']; ?>" 
                           class="flex-1 text-center bg-red-50 hover:bg-red-100 text-red-600 py-2 rounded-lg text-sm font-medium transition"
                           onclick="return confirm('⚠️ Supprimer définitivement cet incident ? Cette action est irréversible.')">
                            🗑️ Supprimer définitivement
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>