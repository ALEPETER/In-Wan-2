<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'superviseur') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id) {
    header('Location: dashboard.php');
    exit();
}

// Récupérer l'incident (sans le message du manager)
$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.id = ?
");
$stmt->execute([$id]);
$incident = $stmt->fetch();

if(!$incident) {
    header('Location: dashboard.php');
    exit();
}

// Liste des techniciens
$stmt = $conn->prepare("SELECT id, nom_complet FROM utilisateurs WHERE role = 'technicien' ORDER BY nom_complet");
$stmt->execute();
$techniciens = $stmt->fetchAll();

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Affecter un technicien - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-800 to-blue-900 min-h-screen p-6">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            <div class="bg-gradient-to-r from-blue-800 to-indigo-800 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <div class="bg-white/20 p-1 rounded-lg">
                        <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-8 w-auto">
                    </div>
                    <div>
                        <h2 class="text-white font-bold"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2>
                        <p class="text-indigo-100 text-xs">Superviseur • <?php echo $date_jour; ?></p>
                    </div>
                </div>
                <a href="dashboard.php" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full text-sm transition">← Retour</a>
            </div>

            <div class="p-6">
                <h1 class="text-2xl font-bold text-gray-800 mb-2">Affecter un technicien</h1>
                <p class="text-gray-500 text-sm mb-6">Incident #<?php echo $incident['id']; ?> – <?php echo htmlspecialchars($incident['equipement']); ?></p>

                <!-- Fiche récapitulative de l'incident (sans message manager) -->
                <div class="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-5 mb-6 border border-gray-200">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-gray-800">Détails de l'incident</h3>
                        <span class="px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">⚠️ <?php echo ucfirst($incident['urgence']); ?></span>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                        <div><span class="text-gray-500">Équipement :</span> <span class="font-medium text-gray-800"><?php echo htmlspecialchars($incident['equipement']); ?></span></div>
                        <div><span class="text-gray-500">Agent :</span> <span class="font-medium text-gray-800"><?php echo htmlspecialchars($incident['agent_nom']); ?></span></div>
                        <div><span class="text-gray-500">Type de panne :</span> <span class="font-medium text-gray-800"><?php echo htmlspecialchars($incident['type_panne']); ?></span></div>
                        <div><span class="text-gray-500">Signalé le :</span> <span class="font-medium text-gray-800"><?php echo date('d/m/Y H:i', strtotime($incident['date_signalement'])); ?></span></div>
                    </div>
                    <div class="mt-3 pt-2 border-t border-gray-200">
                        <span class="text-gray-500 text-sm">Description :</span>
                        <p class="text-gray-700 text-sm mt-1"><?php echo nl2br(htmlspecialchars($incident['description'])); ?></p>
                    </div>
                </div>

                <!-- Formulaire d'affectation -->
                <form action="affecter.php" method="POST" onsubmit="return confirm('Confirmer l’affectation de ce technicien ?')">
                    <input type="hidden" name="incident_id" value="<?php echo $incident['id']; ?>">
                    <div class="mb-6">
                        <label class="block text-gray-700 font-semibold mb-2">Choisir un technicien</label>
                        <div class="relative">
                            <select name="technicien_id" required class="w-full appearance-none bg-white border border-gray-300 rounded-lg px-4 py-3 pr-8 text-gray-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent">
                                <option value="">-- Sélectionnez un technicien --</option>
                                <?php foreach($techniciens as $tech): ?>
                                    <option value="<?php echo $tech['id']; ?>"><?php echo htmlspecialchars($tech['nom_complet']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                            </div>
                        </div>
                        <p class="text-xs text-gray-400 mt-1">Le technicien recevra une notification et pourra démarrer l’intervention.</p>
                    </div>
                    <div class="flex gap-3">
                        <button type="submit" class="flex-1 bg-green-600 hover:bg-green-700 text-white font-medium py-3 rounded-lg transition shadow-md">🔧 Confirmer l’affectation</button>
                        <a href="dashboard.php" class="flex-1 text-center bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 rounded-lg transition">Annuler</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>