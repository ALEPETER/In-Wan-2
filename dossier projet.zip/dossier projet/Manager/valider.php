<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'manager') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id) {
    header('Location: dashboard.php');
    exit();
}

// Récupérer les infos de l'incident
$stmt = $conn->prepare("
    SELECT s.*, u.nom_complet as agent_nom 
    FROM signalements s 
    JOIN utilisateurs u ON s.agent_id = u.id 
    WHERE s.id = ?
");
$stmt->execute([$id]);
$incident = $stmt->fetch();

if(!$incident) {
    header('Location: dashboard.php');
    exit();
}

// Traitement du formulaire
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $commentaire = trim($_POST['commentaire']);
    $stmt = $conn->prepare("UPDATE signalements SET statut = 'valide_manager', date_validation_manager = NOW(), commentaire_manager = ? WHERE id = ?");
    $stmt->execute([$commentaire, $id]);
    $_SESSION['flash_message'] = "Incident validé avec succès.";
    header('Location: dashboard.php');
    exit();
}

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valider l'incident - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-800 to-blue-900 min-h-screen p-6">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            <!-- En-tête -->
            <div class="bg-gradient-to-r from-blue-800 to-indigo-800 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <div class="bg-white/20 p-1 rounded-lg">
                        <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-8 w-auto">
                    </div>
                    <div>
                        <h2 class="text-white font-bold"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></h2>
                        <p class="text-indigo-100 text-xs">Manager • <?php echo $date_jour; ?></p>
                    </div>
                </div>
                <a href="dashboard.php" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full text-sm transition">← Annuler</a>
            </div>

            <div class="p-6">
                <h1 class="text-2xl font-bold text-gray-800 mb-2">Validation stratégique</h1>
                <p class="text-gray-500 text-sm mb-6">Vous êtes sur le point de valider l'incident. Vous pouvez laisser une instruction pour le superviseur.</p>

                <!-- Informations récapitulatives -->
                <div class="bg-gray-50 rounded-xl p-4 mb-6 space-y-2">
                    <div class="flex justify-between">
                        <span class="text-gray-500 text-sm">Incident</span>
                        <span class="font-medium text-gray-800"> <?php echo $incident['id']; ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500 text-sm">Équipement</span>
                        <span class="font-medium text-gray-800"><?php echo htmlspecialchars($incident['equipement']); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500 text-sm">Agent</span>
                        <span class="font-medium text-gray-800"><?php echo htmlspecialchars($incident['agent_nom']); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-500 text-sm">Urgence</span>
                        <span class="font-medium <?php echo $incident['urgence'] == 'critique' ? 'text-red-600' : ($incident['urgence'] == 'urgent' ? 'text-orange-600' : ($incident['urgence'] == 'moyen' ? 'text-yellow-600' : 'text-green-600')); ?>">
                            <?php echo ucfirst($incident['urgence']); ?>
                        </span>
                    </div>
                </div>

                <!-- Formulaire de validation -->
                <form method="POST">
                    <div class="mb-6">
                        <label class="block text-gray-700 font-semibold mb-2">Message pour le superviseur (optionnel)</label>
                        <textarea name="commentaire" rows="4" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Instructions, priorité, pièces nécessaires..."></textarea>
                        <p class="text-xs text-gray-400 mt-1">Ce message sera visible par le superviseur avant qu'il n'affecte un technicien.</p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <button type="submit" class="flex-1 bg-green-600 hover:bg-green-700 text-white font-medium py-2 rounded-lg transition shadow-sm">✅ Valider l'incident</button>
                        <a href="dashboard.php" class="flex-1 text-center bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 rounded-lg transition">Annuler</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>